// static/js/game.js
document.addEventListener('DOMContentLoaded', () => {
    // Game elements
    const startScreen = document.getElementById('start-screen');
    const gameScreen = document.getElementById('game-screen');
    const startBtn = document.getElementById('start-btn');
    const restartBtn = document.getElementById('restart-btn');
    const gameOverScreen = document.getElementById('game-over');
    const scoreDisplay = document.getElementById('score-display');
    const levelDisplay = document.getElementById('level-display');
    const powerupDisplay = document.getElementById('powerup-display');
    const healthDisplay = document.getElementById('health-display');
    const finalScoreDisplay = document.getElementById('final-score');
    const levelBtns = document.querySelectorAll('.level-btn');
    const bgMusic = document.getElementById('bg-music');

    // Game variables
    let scene, camera, renderer, drone, bullets = [], enemies = [], powerups = [], particles = [];
    let score = 0, health = 5, currentLevel = 1;
    let gameRunning = false;
    let bulletSpeed = 0.05, enemySpeed = 0.03, powerupSpeed = 0.02;
    let bulletSpawnRate = 2000, enemySpawnRate = 5000, powerupSpawnRate = 10000;
    let lastBulletTime = 0, lastEnemyTime = 0, lastPowerupTime = 0;
    let activePowerup = null, powerupEndTime = 0;
    let audioListener, engineSound, collisionSound, powerupSound, shootSound;
    let environment = { skybox: null, ground: null };

    // Controls
    let keys = {
        ArrowUp: false,
        ArrowDown: false,
        ArrowLeft: false,
        ArrowRight: false,
        Space: false
    };

    // Powerup types
    const POWERUP_TYPES = {
        SHIELD: { name: 'Shield', duration: 10000, color: 0x00aaff },
        SPEED: { name: 'Speed Boost', duration: 8000, color: 0x00ff00 },
        DOUBLE: { name: 'Double Points', duration: 12000, color: 0xffaa00 }
    };

    // Enemy types
    const ENEMY_TYPES = {
        BASIC: { speed: 0.03, health: 1, score: 5, model: 'enemy1.glb' },
        ADVANCED: { speed: 0.05, health: 2, score: 10, model: 'enemy2.glb' },
        BOSS: { speed: 0.02, health: 5, score: 25, model: 'enemy2.glb', scale: 1.5 }
    };

    // Level configurations
    const LEVELS = {
        1: { name: 'Forest', sky: 'sky1.jpg', groundColor: 0x3a5f0b, bulletColor: 0xff0000, fogColor: 0x87CEEB },
        2: { name: 'Desert', sky: 'sky2.jpg', groundColor: 0xd2b48c, bulletColor: 0xff6600, fogColor: 0xf5deb3 },
        3: { name: 'Space', sky: null, groundColor: 0x000000, bulletColor: 0x00ffff, fogColor: 0x000000, stars: true }
    };

    // Event listeners
    startBtn.addEventListener('click', startGame);
    restartBtn.addEventListener('click', startGame);
    levelBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            currentLevel = parseInt(btn.dataset.level);
            levelBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
        });
    });

    // Initialize game
    function startGame() {
        startScreen.style.display = 'none';
        gameScreen.style.display = 'block';
        gameOverScreen.style.display = 'none';
        
        // Reset game state
        score = 0;
        health = 5;
        bulletSpeed = 0.05;
        enemySpeed = 0.03;
        bulletSpawnRate = 2000;
        enemySpawnRate = 5000;
        powerupSpawnRate = 10000;
        activePowerup = null;
        
        updateHUD();
        
        // Initialize Three.js scene
        initScene();
        
        // Load assets
        loadAssets().then(() => {
            gameRunning = true;
            bgMusic.volume = 0.3;
            bgMusic.play();
            animate();
        });
    }

    function initScene() {
        // Clear previous scene if exists
        if (renderer) {
            gameScreen.removeChild(renderer.domElement);
        }
        
        // Create scene
        scene = new THREE.Scene();
        
        // Setup environment based on level
        setupEnvironment();
        
        // Create camera
        camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.set(0, 5, 15);
        camera.lookAt(0, 0, 0);
        
        // Create renderer
        renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.shadowMap.enabled = true;
        gameScreen.appendChild(renderer.domElement);
        
        // Add lights
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
        scene.add(ambientLight);
        
        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
        directionalLight.position.set(1, 1, 1);
        directionalLight.castShadow = true;
        directionalLight.shadow.mapSize.width = 1024;
        directionalLight.shadow.mapSize.height = 1024;
        scene.add(directionalLight);
        
        // Create audio listener
        audioListener = new THREE.AudioListener();
        camera.add(audioListener);
        
        // Load sounds
        loadSounds();
        
        // Add event listeners
        window.addEventListener('resize', onWindowResize);
        window.addEventListener('keydown', onKeyDown);
        window.addEventListener('keyup', onKeyUp);
    }

    function setupEnvironment() {
        const levelConfig = LEVELS[currentLevel];
        
        // Clear previous environment
        if (environment.skybox) scene.remove(environment.skybox);
        if (environment.ground) scene.remove(environment.ground);
        
        // Set fog
        scene.fog = new THREE.Fog(levelConfig.fogColor, 10, 50);
        
        // Create skybox
        if (levelConfig.sky) {
            const loader = new THREE.TextureLoader();
            loader.load(`static/textures/${levelConfig.sky}`, (texture) => {
                texture.mapping = THREE.EquirectangularReflectionMapping;
                scene.background = texture;
            });
        } else if (levelConfig.stars) {
            // Create starfield for space level
            const starsGeometry = new THREE.BufferGeometry();
            const starsMaterial = new THREE.PointsMaterial({
                color: 0xffffff,
                size: 0.1,
                transparent: true
            });
            
            const starsVertices = [];
            for (let i = 0; i < 10000; i++) {
                const x = (Math.random() - 0.5) * 2000;
                const y = (Math.random() - 0.5) * 2000;
                const z = (Math.random() - 0.5) * 2000;
                starsVertices.push(x, y, z);
            }
            
            starsGeometry.setAttribute('position', new THREE.Float32BufferAttribute(starsVertices, 3));
            const starField = new THREE.Points(starsGeometry, starsMaterial);
            scene.add(starField);
        }
        
        // Create ground
        const groundGeometry = new THREE.PlaneGeometry(100, 100);
        const groundMaterial = new THREE.MeshStandardMaterial({ 
            color: levelConfig.groundColor,
            side: THREE.DoubleSide,
            roughness: 0.8
        });
        const ground = new THREE.Mesh(groundGeometry, groundMaterial);
        ground.rotation.x = -Math.PI / 2;
        ground.receiveShadow = true;
        scene.add(ground);
        
        environment.ground = ground;
    }

    async function loadAssets() {
        // Load drone model
        await loadDroneModel();
        
        // Preload other models
        // (In a real game, you'd want to preload all assets before starting)
    }

    function loadDroneModel() {
        return new Promise((resolve) => {
            // Using a simple model with GLTFLoader
            const loader = new THREE.GLTFLoader();
            loader.load('static/models/drone.glb', (gltf) => {
                drone = gltf.scene;
                drone.scale.set(0.5, 0.5, 0.5);
                drone.position.set(0, 3, 0);
                drone.traverse((child) => {
                    if (child.isMesh) {
                        child.castShadow = true;
                    }
                });
                scene.add(drone);
                resolve();
            }, undefined, (error) => {
                console.error('Error loading drone model:', error);
                // Fallback to basic geometry
                createBasicDrone();
                resolve();
            });
        });
    }

    function createBasicDrone() {
        const droneGeometry = new THREE.BoxGeometry(1, 0.5, 1);
        const droneMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x4CAF50,
            emissive: 0x004400,
            emissiveIntensity: 0.5,
            shininess: 100
        });
        drone = new THREE.Mesh(droneGeometry, droneMaterial);
        drone.position.y = 3;
        drone.castShadow = true;
        scene.add(drone);
        
        // Add propellers
        for (let i = 0; i < 4; i++) {
            const angle = (i * Math.PI / 2) + (Math.PI / 4);
            const propellerGeometry = new THREE.CylinderGeometry(0.2, 0.2, 0.05, 16);
            const propellerMaterial = new THREE.MeshPhongMaterial({ color: 0x888888 });
            const propeller = new THREE.Mesh(propellerGeometry, propellerMaterial);
            
            propeller.position.x = Math.cos(angle) * 0.6;
            propeller.position.z = Math.sin(angle) * 0.6;
            propeller.position.y = 0.25;
            propeller.rotation.x = Math.PI / 2;
            propeller.castShadow = true;
            
            drone.add(propeller);
        }
    }

    function loadSounds() {
        // Engine sound
        engineSound = new THREE.PositionalAudio(audioListener);
        const engineAudioLoader = new THREE.AudioLoader();
        engineAudioLoader.load('static/sounds/engine.mp3', (buffer) => {
            engineSound.setBuffer(buffer);
            engineSound.setRefDistance(5);
            engineSound.setLoop(true);
            engineSound.setVolume(0.5);
            drone.add(engineSound);
            engineSound.play();
        });
        
        // Collision sound
        collisionSound = new THREE.Audio(audioListener);
        const collisionAudioLoader = new THREE.AudioLoader();
        collisionAudioLoader.load('static/sounds/collision.mp3', (buffer) => {
            collisionSound.setBuffer(buffer);
            collisionSound.setVolume(0.7);
        });
        
        // Powerup sound
        powerupSound = new THREE.Audio(audioListener);
        const powerupAudioLoader = new THREE.AudioLoader();
        powerupAudioLoader.load('static/sounds/powerup.mp3', (buffer) => {
            powerupSound.setBuffer(buffer);
            powerupSound.setVolume(0.5);
        });
        
        // Shoot sound
        shootSound = new THREE.Audio(audioListener);
        const shootAudioLoader = new THREE.AudioLoader();
        shootAudioLoader.load('static/sounds/shoot.mp3', (buffer) => {
            shootSound.setBuffer(buffer);
            shootSound.setVolume(0.3);
        });
    }

    function spawnBullet() {
        const loader = new THREE.GLTFLoader();
        loader.load('static/models/bullet.glb', (gltf) => {
            const bullet = gltf.scene;
            bullet.scale.set(0.3, 0.3, 0.3);
            
            // Random position outside the view
            const side = Math.floor(Math.random() * 4);
            let x, z;
            
            switch(side) {
                case 0: x = Math.random() * 30 - 15; z = -20; break;
                case 1: x = 20; z = Math.random() * 30 - 15; break;
                case 2: x = Math.random() * 30 - 15; z = 20; break;
                case 3: x = -20; z = Math.random() * 30 - 15; break;
            }
            
            bullet.position.set(x, Math.random() * 5 + 1, z);
            bullet.userData = { speed: bulletSpeed, damage: 1 };
            scene.add(bullet);
            bullets.push(bullet);
            
            // Play shoot sound
            if (shootSound) shootSound.play();
        }, undefined, () => {
            // Fallback to basic bullet
            createBasicBullet();
        });
    }

    function createBasicBullet() {
        const bulletGeometry = new THREE.SphereGeometry(0.3, 16, 16);
        const bulletMaterial = new THREE.MeshPhongMaterial({ 
            color: LEVELS[currentLevel].bulletColor,
            emissive: 0x220000,
            emissiveIntensity: 0.5
        });
        const bullet = new THREE.Mesh(bulletGeometry, bulletMaterial);
        
        // Random position outside the view
        const side = Math.floor(Math.random() * 4);
        let x, z;
        
        switch(side) {
            case 0: x = Math.random() * 30 - 15; z = -20; break;
            case 1: x = 20; z = Math.random() * 30 - 15; break;
            case 2: x = Math.random() * 30 - 15; z = 20; break;
            case 3: x = -20; z = Math.random() * 30 - 15; break;
        }
        
        bullet.position.set(x, Math.random() * 5 + 1, z);
        bullet.castShadow = true;
        bullet.userData = { speed: bulletSpeed, damage: 1 };
        scene.add(bullet);
        bullets.push(bullet);
        
        // Play shoot sound
        if (shootSound) shootSound.play();
    }

    function spawnEnemy() {
        const enemyTypes = Object.values(ENEMY_TYPES);
        const enemyType = score > 30 ? 
                         (Math.random() > 0.7 ? ENEMY_TYPES.BOSS : 
                          Math.random() > 0.5 ? ENEMY_TYPES.ADVANCED : ENEMY_TYPES.BASIC) :
                         (Math.random() > 0.7 ? ENEMY_TYPES.ADVANCED : ENEMY_TYPES.BASIC);
        
        const loader = new THREE.GLTFLoader();
        loader.load(`static/models/${enemyType.model}`, (gltf) => {
            const enemy = gltf.scene;
            enemy.scale.set(enemyType.scale || 1, enemyType.scale || 1, enemyType.scale || 1);
            
            // Random position outside the view
            const side = Math.floor(Math.random() * 4);
            let x, z;
            
            switch(side) {
                case 0: x = Math.random() * 30 - 15; z = -20; break;
                case 1: x = 20; z = Math.random() * 30 - 15; break;
                case 2: x = Math.random() * 30 - 15; z = 20; break;
                case 3: x = -20; z = Math.random() * 30 - 15; break;
            }
            
            enemy.position.set(x, Math.random() * 5 + 1, z);
            enemy.userData = {
                type: enemyType,
                health: enemyType.health,
                speed: enemyType.speed,
                score: enemyType.score
            };
            scene.add(enemy);
            enemies.push(enemy);
        }, undefined, () => {
            // Fallback to basic enemy
            createBasicEnemy(enemyType);
        });
    }

    function createBasicEnemy(enemyType) {
        const enemyGeometry = new THREE.BoxGeometry(1, 1, 1);
        const enemyMaterial = new THREE.MeshPhongMaterial({ 
            color: 0xff0000,
            emissive: 0x440000,
            emissiveIntensity: 0.3
        });
        const enemy = new THREE.Mesh(enemyGeometry, enemyMaterial);
        
        // Random position outside the view
        const side = Math.floor(Math.random() * 4);
        let x, z;
        
        switch(side) {
            case 0: x = Math.random() * 30 - 15; z = -20; break;
            case 1: x = 20; z = Math.random() * 30 - 15; break;
            case 2: x = Math.random() * 30 - 15; z = 20; break;
            case 3: x = -20; z = Math.random() * 30 - 15; break;
        }
        
        enemy.position.set(x, Math.random() * 5 + 1, z);
        enemy.castShadow = true;
        enemy.userData = {
            type: enemyType,
            health: enemyType.health,
            speed: enemyType.speed,
            score: enemyType.score
        };
        scene.add(enemy);
        enemies.push(enemy);
    }

    function spawnPowerup() {
        const powerupTypes = Object.values(POWERUP_TYPES);
        const powerupType = powerupTypes[Math.floor(Math.random() * powerupTypes.length)];
        
        const geometry = new THREE.SphereGeometry(0.5, 16, 16);
        const material = new THREE.MeshPhongMaterial({
            color: powerupType.color,
            emissive: powerupType.color,
            emissiveIntensity: 0.3,
            transparent: true,
            opacity: 0.8
        });
        const powerup = new THREE.Mesh(geometry, material);
        
        // Random position
        powerup.position.set(
            Math.random() * 30 - 15,
            Math.random() * 5 + 1,
            Math.random() * 30 - 15
        );
        
        powerup.castShadow = true;
        powerup.userData = { type: powerupType };
        scene.add(powerup);
        powerups.push(powerup);
    }

    function createParticles(position, color, count = 20) {
        const particlesGeometry = new THREE.BufferGeometry();
        const particlesMaterial = new THREE.PointsMaterial({
            color: color,
            size: 0.2,
            transparent: true,
            opacity: 0.8,
            blending: THREE.AdditiveBlending
        });
        
        const particlesVertices = [];
        for (let i = 0; i < count; i++) {
            particlesVertices.push(
                position.x + (Math.random() - 0.5) * 2,
                position.y + (Math.random() - 0.5) * 2,
                position.z + (Math.random() - 0.5) * 2
            );
        }
        
        particlesGeometry.setAttribute('position', new THREE.Float32BufferAttribute(particlesVertices, 3));
        const particleSystem = new THREE.Points(particlesGeometry, particlesMaterial);
        particleSystem.userData = { life: 60 }; // 1 second at 60fps
        scene.add(particleSystem);
        particles.push(particleSystem);
    }

    function updateHUD() {
        scoreDisplay.textContent = `Score: ${score}`;
        levelDisplay.textContent = `Level: ${LEVELS[currentLevel].name}`;
        healthDisplay.textContent = `Health: ${'■'.repeat(health)}`;
        
        if (activePowerup) {
            const remaining = Math.max(0, powerupEndTime - Date.now());
            powerupDisplay.textContent = `Power: ${activePowerup.name} (${(remaining/1000).toFixed(1)}s)`;
            powerupDisplay.style.color = `#${activePowerup.color.toString(16)}`;
        } else {
            powerupDisplay.textContent = 'Power: None';
            powerupDisplay.style.color = '#ffffff';
        }
        
        // Adjust difficulty based on score
        if (score >= 40) {
            bulletSpeed = 0.15;
            enemySpeed = 0.07;
            bulletSpawnRate = 800;
            enemySpawnRate = 3000;
        } else if (score >= 20) {
            bulletSpeed = 0.1;
            enemySpeed = 0.05;
            bulletSpawnRate = 1200;
            enemySpawnRate = 4000;
        }
    }

    function checkCollisions() {
        const droneBox = new THREE.Box3().setFromObject(drone);
        
        // Check bullet collisions
        for (let i = bullets.length - 1; i >= 0; i--) {
            const bullet = bullets[i];
            const bulletBox = new THREE.Box3().setFromObject(bullet);
            
            if (droneBox.intersectsBox(bulletBox)) {
                // Collision detected
                if (activePowerup && activePowerup.name === 'Shield') {
                    // Shield protects from damage
                    createParticles(bullet.position, 0x00aaff);
                } else {
                    takeDamage(bullet.userData.damage);
                    createParticles(bullet.position, 0xff0000);
                }
                
                scene.remove(bullet);
                bullets.splice(i, 1);
                continue;
            }
            
            // Remove bullets that are too far
            if (bullet.position.length() > 50) {
                scene.remove(bullet);
                bullets.splice(i, 1);
                createParticles(bullet.position, 0xffff00);
                
                if (activePowerup && activePowerup.name === 'Double Points') {
                    score += 2;
                } else {
                    score += 1;
                }
                updateHUD();
            }
        }
        
        // Check enemy collisions
        for (let i = enemies.length - 1; i >= 0; i--) {
            const enemy = enemies[i];
            const enemyBox = new THREE.Box3().setFromObject(enemy);
            
            if (droneBox.intersectsBox(enemyBox)) {
                // Collision with enemy
                takeDamage(enemy.userData.type.health);
                createParticles(enemy.position, 0xff0000, 50);
                
                scene.remove(enemy);
                enemies.splice(i, 1);
            }
        }
        
        // Check powerup collisions
        for (let i = powerups.length - 1; i >= 0; i--) {
            const powerup = powerups[i];
            const powerupBox = new THREE.Box3().setFromObject(powerup);
            
            if (droneBox.intersectsBox(powerupBox)) {
                // Collect powerup
                activatePowerup(powerup.userData.type);
                createParticles(powerup.position, powerup.userData.type.color, 30);
                
                scene.remove(powerup);
                powerups.splice(i, 1);
                
                if (powerupSound) powerupSound.play();
            }
        }
    }

    function takeDamage(amount) {
        if (collisionSound) collisionSound.play();
        
        health -= amount;
        updateHUD();
        
        // Camera shake effect
        camera.position.x += (Math.random() - 0.5) * 0.5;
        camera.position.y += (Math.random() - 0.5) * 0.5;
        setTimeout(() => {
            camera.position.set(0, 5, 15);
        }, 100);
        
        if (health <= 0) {
            gameOver();
        }
    }

    function activatePowerup(powerup) {
        activePowerup = powerup;
        powerupEndTime = Date.now() + powerup.duration;
        updateHUD();
        
        // Visual effect for shield
        if (powerup.name === 'Shield') {
            const shieldGeometry = new THREE.SphereGeometry(1.2, 32, 32);
            const shieldMaterial = new THREE.MeshPhongMaterial({
                color: powerup.color,
                transparent: true,
                opacity: 0.3,
                wireframe: true
            });
            const shield = new THREE.Mesh(shieldGeometry, shieldMaterial);
            shield.name = 'shield';
            drone.add(shield);
        }
    }

    function deactivatePowerup() {
        if (activePowerup) {
            // Remove shield if active
            if (activePowerup.name === 'Shield') {
                const shield = drone.getObjectByName('shield');
                if (shield) drone.remove(shield);
            }
            
            activePowerup = null;
            updateHUD();
        }
    }

    function gameOver() {
        gameRunning = false;
        finalScoreDisplay.textContent = score;
        gameOverScreen.style.display = 'flex';
        bgMusic.pause();
        if (engineSound) engineSound.stop();
        
        // Clean up
        while (bullets.length > 0) {
            const bullet = bullets.pop();
            scene.remove(bullet);
        }
        while (enemies.length > 0) {
            const enemy = enemies.pop();
            scene.remove(enemy);
        }
        while (powerups.length > 0) {
            const powerup = powerups.pop();
            scene.remove(powerup);
        }
        while (particles.length > 0) {
            const particle = particles.pop();
            scene.remove(particle);
        }
        
        // Reset drone position
        drone.position.set(0, 3, 0);
        deactivatePowerup();
    }

    function animate() {
        if (!gameRunning) return;
        
        requestAnimationFrame(animate);
        
        // Move drone based on keyboard input
        const moveSpeed = activePowerup?.name === 'Speed Boost' ? 0.2 : 0.1;
        if (keys.ArrowUp && drone.position.z > -10) drone.position.z -= moveSpeed;
        if (keys.ArrowDown && drone.position.z < 10) drone.position.z += moveSpeed;
        if (keys.ArrowLeft && drone.position.x > -10) drone.position.x -= moveSpeed;
        if (keys.ArrowRight && drone.position.x < 10) drone.position.x += moveSpeed;
        
        // Rotate drone based on movement
        drone.rotation.z = (keys.ArrowLeft ? 0.1 : (keys.ArrowRight ? -0.1 : 0));
        drone.rotation.x = (keys.ArrowUp ? -0.1 : (keys.ArrowDown ? 0.1 : 0));
        
        // Animate propellers
        if (drone.children) {
            drone.children.forEach(child => {
                if (child.type === 'Mesh') {
                    child.rotation.z += 0.3;
                }
            });
        }
        
        // Spawn bullets
        const currentTime = Date.now();
        if (currentTime - lastBulletTime > bulletSpawnRate) {
            spawnBullet();
            lastBulletTime = currentTime;
        }
        
        // Spawn enemies
        if (currentTime - lastEnemyTime > enemySpawnRate) {
            spawnEnemy();
            lastEnemyTime = currentTime;
        }
        
        // Spawn powerups
        if (currentTime - lastPowerupTime > powerupSpawnRate && !activePowerup) {
            spawnPowerup();
            lastPowerupTime = currentTime;
        }
        
        // Move bullets toward center
        bullets.forEach(bullet => {
            const direction = new THREE.Vector3().subVectors(drone.position, bullet.position).normalize();
            bullet.position.add(direction.multiplyScalar(bullet.userData.speed));
        });
        
        // Move enemies toward drone
        enemies.forEach(enemy => {
            const direction = new THREE.Vector3().subVectors(drone.position, enemy.position).normalize();
            enemy.position.add(direction.multiplyScalar(enemy.userData.speed));
            enemy.lookAt(drone.position);
        });
        
        // Move powerups (float in place with slight movement)
        powerups.forEach(powerup => {
            powerup.position.y += Math.sin(Date.now() * 0.001) * 0.01;
            powerup.rotation.y += 0.02;
        });
        
        // Update particles
        for (let i = particles.length - 1; i >= 0; i--) {
            const particle = particles[i];
            particle.userData.life--;
            
            if (particle.userData.life <= 0) {
                scene.remove(particle);
                particles.splice(i, 1);
            } else {
                // Move particles outward
                const positions = particle.geometry.attributes.position.array;
                for (let j = 0; j < positions.length; j += 3) {
                    positions[j] += (Math.random() - 0.5) * 0.1;
                    positions[j+1] += (Math.random() - 0.5) * 0.1;
                    positions[j+2] += (Math.random() - 0.5) * 0.1;
                }
                particle.geometry.attributes.position.needsUpdate = true;
            }
        }
        
        // Check powerup expiration
        if (activePowerup && Date.now() > powerupEndTime) {
            deactivatePowerup();
        }
        
        checkCollisions();
        renderer.render(scene, camera);
    }

    function onWindowResize() {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    }

    function onKeyDown(event) {
        if (keys.hasOwnProperty(event.key)) {
            keys[event.key] = true;
            event.preventDefault();
        }
    }

    function onKeyUp(event) {
        if (keys.hasOwnProperty(event.key)) {
            keys[event.key] = false;
            event.preventDefault();
        }
    }
});